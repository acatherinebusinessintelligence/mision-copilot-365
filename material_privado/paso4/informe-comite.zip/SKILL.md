---
name: informe-comite
description: Genera un informe ejecutivo para el comité del Proyecto Horizonte (documento de Word por defecto, o presentación de PowerPoint si se pide) a partir del análisis de trazabilidad, con cifras, un gráfico, casos críticos y recomendaciones separadas de la evidencia. Úsala cuando pidan un informe, reporte para la dirección, presentación para el comité o resumen ejecutivo de los hallazgos.
---

# Informe para comité

Produce un entregable que la dirección pueda leer en 3 minutos. Se basa en los datos del registro de trazabilidad; si todavía no se analizaron, aplica primero el procedimiento de la habilidad `analizar-trazabilidad`.

## Formato

- Por defecto, un documento de Word.
- Si la persona pide presentación, un PowerPoint de máximo 5 diapositivas.
- Si no está claro, pregunta una vez: "¿Lo prefieres en Word o en PowerPoint?"

## Estructura

1. **Título:** Proyecto Horizonte · Informe de hallazgos y decisiones, con el periodo analizado.
2. **Resumen ejecutivo:** 3 viñetas.
3. **Cifras clave:** total de casos, críticos, aprobados, rechazados, decididos por la automatización y decididos por personas.
4. **Gráfico:** barras con los casos por Ruta, y una segunda serie o gráfico con automatización frente a persona.
5. **Casos críticos:** tabla con fecha, asunto, decisión y quién decidió.
6. **Casos que requieren atención:** aprobaciones vencidas, datos incompletos o posibles duplicados.
7. **Recomendaciones:** máximo 3, cada una marcada como *recomendación (inferencia)*.
8. **Nota de método:** fuente de datos, fecha de corte y aclaración de que el informe fue generado con IA y debe ser revisado por una persona antes de circular.

## Reglas

- Cada cifra debe salir de los datos. Si falta un dato, escribe "Sin datos" en lugar de estimarlo.
- Separa claramente lo que muestran los datos de lo que se recomienda.
- No incluyas datos personales más allá de los nombres de quienes aprobaron, y solo si son necesarios para la trazabilidad.
- Lenguaje claro y sin tecnicismos de Power Automate: habla de "casos", "aprobaciones" y "decisiones automáticas".
- Al entregar, recuerda: "Revisa el informe antes de enviarlo al comité."
