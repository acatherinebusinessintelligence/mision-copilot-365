---
name: analizar-trazabilidad
description: Analiza el registro de trazabilidad del flujo Horizonte (archivo Horizonte_Trazabilidad.xlsx, tabla Registro) para mostrar cuántos hallazgos hubo por nivel, quién decidió cada caso (la automatización o una persona), cuántos se aprobaron o rechazaron y qué casos requieren atención. Úsala cuando pidan revisar, auditar, resumir o medir las decisiones registradas por el flujo.
---

# Analizar trazabilidad

Analiza lo que el flujo de Power Automate registró y responde con cifras verificables. Separa siempre la evidencia (lo que está en el archivo) de la inferencia (lo que interpretas).

## Fuente

El archivo `Horizonte_Trazabilidad.xlsx`, tabla `Registro`, con estas columnas:

| Columna | Contenido |
|---|---|
| Fecha | Fecha y hora de recepción del correo (hora de Colombia) |
| Remitente | Quién reportó |
| Asunto | Asunto del reporte |
| Ruta | `ALERTA_CRITICA`, `REGISTRO_NORMAL` u otra ruta configurada |
| Decision | Qué pasó con el caso |

Si el archivo no está en el conocimiento del agente ni adjunto en la conversación, pide a la persona que lo adjunte. No supongas su contenido.

## Cómo interpretar la columna Decision

- `Approve · nombre` → decidió una persona: aprobado.
- `Reject · nombre` → decidió una persona: rechazado.
- `NO_REQUIERE` → no hubo decisión humana.
- `AUTO_REGISTRADO` o `AUTO_SUPERVISADO` → decidió la automatización (si el flujo tiene esas rutas).
- Cualquier otro valor: repórtalo tal cual y señálalo como no reconocido.

## Proceso

1. Usa código para leer el archivo y calcular. No cuentes a ojo.
2. Calcula:
   - Total de casos y rango de fechas.
   - Casos por Ruta.
   - Quién decidió: automatización frente a persona (número y porcentaje).
   - Aprobados y rechazados, y por aprobador.
   - Casos por remitente.
3. Busca casos que requieren atención:
   - `ALERTA_CRITICA` con Decision `NO_REQUIERE` o vacía (posible aprobación vencida o fallida).
   - Filas con datos vacíos o valores no reconocidos.
   - Asuntos repetidos en poco tiempo (posible duplicado o bucle).
   - Casos en `REGISTRO_NORMAL` cuyo asunto sugiere un riesgo alto (seguridad de personas, ambiental, normativo, cortes de servicio). Señálalos como *inferencia*: puede ser un error de formato en la línea `Criticidad:` del correo o una clasificación equivocada. Recomienda verificarlos con una persona.
4. Responde con el formato de abajo.

## Formato de salida

**Resumen** (3 viñetas máximo).

**Cifras** (tabla).

**Casos que requieren atención** (lista con fecha y asunto, o "Ninguno").

**Evidencia e inferencia:**
- *Evidencia:* lo que muestran los datos.
- *Inferencia:* posibles explicaciones, marcadas como tales.

**Siguiente paso sugerido** (una línea). La decisión es de la persona.

## Reglas

- No inventes filas, nombres ni cifras.
- Si hay muy pocos casos para sacar conclusiones, dilo.
- No juzgues a las personas que aprobaron o rechazaron; describe los datos.
